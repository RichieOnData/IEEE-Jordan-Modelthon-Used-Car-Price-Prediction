import pandas as pd
import numpy as np
from catboost import CatBoostRegressor
from sklearn.model_selection import train_test_split

# Load data
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')

# Define preprocessing functions
def preprocess_data(df):
    # Create a copy to avoid modifying the original data
    df = df.copy()
    
    # Convert Year to numeric
    df['Year'] = pd.to_numeric(df['Year'], errors='coerce')
    # Convert Kilometers to numeric
    df['Kilometers'] = pd.to_numeric(df['Kilometers'], errors='coerce')
    
    # Convert Scraped_Time to datetime and extract year
    df['Scraped_Time'] = pd.to_datetime(df['Scraped_Time'])
    df['Scraped_Year'] = df['Scraped_Time'].dt.year
    df['Age'] = df['Scraped_Year'] - df['Year']
    df.drop(['Scraped_Time', 'Scraped_Year'], axis=1, inplace=True)
    
    # Annual Kilometers
    df['Annual_Kilometers'] = df['Kilometers'] / (df['Age'] + 1)
    
    # Handle Battery features for non-EV/Hybrid
    df['Battery Capacity'] = np.where(df['Fuel'].isin(['Electric', 'Hybrid']), df['Battery Capacity'], 0)
    df['Battery Range'] = np.where(df['Fuel'].isin(['Electric', 'Hybrid']), df['Battery Range'], 0)
    df['Battery Capacity'] = df['Battery Capacity'].fillna(0)
    df['Battery Range'] = df['Battery Range'].fillna(0)
    
    # Count options for Interior, Exterior, Technology
    option_cols = ['Interior Options', 'Exterior Options', 'Technology Options']
    for col in option_cols:
        df[col] = df[col].fillna('')
        df[col + '_count'] = df[col].apply(lambda x: 0 if x == '' else len(x.split(',')))
    df.drop(option_cols, axis=1, inplace=True)
    
    # Ordinal encoding
    body_condition_mapping = {'Excellent': 3, 'Good': 2, 'Fair': 1, 'Damaged': 0}
    paint_mapping = {'Original': 1, 'Repainted': 0}
    car_license_mapping = {'Valid': 2, 'Expired': 1, 'Not Applicable': 0, 'Missing': 0}
    car_customs_mapping = {'Cleared': 1, 'Not Cleared': 0, 'Missing': 0}
    condition_mapping = {'New': 1, 'Used': 0}
    insurance_mapping = {'Yes': 1, 'No': 0, 'Missing': 0}
    
    df['Body Condition'] = df['Body Condition'].map(body_condition_mapping).fillna(0).astype(int)
    df['Paint'] = df['Paint'].map(paint_mapping).fillna(0).astype(int)
    df['Car License'] = df['Car License'].map(car_license_mapping).fillna(0).astype(int)
    df['Car Customs'] = df['Car Customs'].map(car_customs_mapping).fillna(0).astype(int)
    df['Condition'] = df['Condition'].map(condition_mapping).fillna(0).astype(int)
    df['Insurance'] = df['Insurance'].map(insurance_mapping).fillna(0).astype(int)
    
    # Fill missing categorical values with 'Missing'
    categorical_cols = ['Car Make', 'Model', 'Trim', 'Body Type', 'Fuel', 'Transmission',
                        'Exterior Color', 'Interior Color', 'Regional Specs', 'Payment Method', 'City',
                        'Neighborhood', 'Category', 'Subcategory']
    for col in categorical_cols:
        if col in df.columns:
            df[col] = df[col].fillna('Missing')
    
    # Fill missing numerical values with median (fallback to 0 if median is NaN)
    numerical_cols = ['Year', 'Kilometers', 'Number of Seats', 'Engine Size (cc)',
                      'Description_Score', 'Battery Capacity', 'Battery Range', 'Age',
                      'Annual_Kilometers']
    for col in numerical_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
            median = df[col].median()
            if np.isnan(median):
                median = 0
            df[col] = df[col].fillna(median)
    
    return df

# Preprocess train and test data
train_preprocessed = preprocess_data(train)
test_preprocessed = preprocess_data(test)

# Debug: Print columns with missing values after preprocessing
missing_cols = train_preprocessed.columns[train_preprocessed.isnull().any()].tolist()
if missing_cols:
    print('Columns with missing values after preprocessing:', missing_cols)
    print(train_preprocessed[missing_cols].isnull().sum())
else:
    print('No missing values in train_preprocessed.')

# Separate features and target
X = train_preprocessed.drop('Price', axis=1)
y = np.log1p(train_preprocessed['Price'])  # Log transformation

# Split data
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

# Identify categorical features for CatBoost
cat_features = [X.columns.get_loc(col) for col in X.select_dtypes(include=['object', 'category']).columns]
print('CatBoost categorical features:', X.select_dtypes(include=['object', 'category']).columns.tolist())

# Initialize and train CatBoost model
model = CatBoostRegressor(
    cat_features=cat_features,
    random_seed=42,
    early_stopping_rounds=50,
    verbose=100,
    eval_metric='RMSE',
    loss_function='RMSE'
)

model.fit(X_train, y_train, eval_set=(X_val, y_val))

# Predict on test data
test_pred_log = model.predict(test_preprocessed)
test_pred = np.expm1(test_pred_log)  # Reverse log transformation

# Create submission file
submission = pd.DataFrame({
    'Id': test['Id'],
    'Price': test_pred
})

submission.to_csv('submission.csv', index=False)